package app;

public class Main {


	public static void main(String[] args) {
		
		new GUIClock().setVisible(true);

	}

}
